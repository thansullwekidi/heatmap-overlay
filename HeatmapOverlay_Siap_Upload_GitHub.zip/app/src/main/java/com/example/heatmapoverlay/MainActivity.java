package com.example.heatmapoverlay;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_CODE_OVERLAY_PERMISSION = 101;
    private static final int REQ_CODE_LOCATION_PERMISSION = 102;
    private static final int REQ_CODE_NOTIFICATION_PERMISSION = 103;

    private Button btnStartService;
    private Button btnStopService;
    private TextView tvStatusSummary;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnStartService = findViewById(R.id.btn_start_service);
        btnStopService = findViewById(R.id.btn_stop_service);
        tvStatusSummary = findViewById(R.id.tv_status_summary);

        btnStartService.setOnClickListener(v -> checkPermissionsAndStartService());
        btnStopService.setOnClickListener(v -> stopHeatmapService());

        updateUIState();
    }

    private void checkPermissionsAndStartService() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Mohon izinkan 'Tampilkan di atas aplikasi lain'", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())
                );
                startActivityForResult(intent, REQ_CODE_OVERLAY_PERMISSION);
                return;
            }
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                    },
                    REQ_CODE_LOCATION_PERMISSION
            );
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                        this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS},
                        REQ_CODE_NOTIFICATION_PERMISSION
                );
                return;
            }
        }

        startHeatmapService();
    }

    private void startHeatmapService() {
        Intent serviceIntent = new Intent(this, HeatmapService.class);
        ContextCompat.startForegroundService(this, serviceIntent);
        Toast.makeText(this, "Heatmap Overlay Service Dijalankan!", Toast.LENGTH_SHORT).show();
        updateUIState();
    }

    private void stopHeatmapService() {
        Intent serviceIntent = new Intent(this, HeatmapService.class);
        stopService(serviceIntent);
        Toast.makeText(this, "Heatmap Overlay Service Dihentikan.", Toast.LENGTH_SHORT).show();
        updateUIState();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_CODE_OVERLAY_PERMISSION) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (Settings.canDrawOverlays(this)) {
                    Toast.makeText(this, "Izin Overlay diberikan!", Toast.LENGTH_SHORT).show();
                    checkPermissionsAndStartService();
                } else {
                    Toast.makeText(this, "Izin Overlay Ditolak. Fitur floating widget tidak dapat berjalan.", Toast.LENGTH_LONG).show();
                }
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQ_CODE_LOCATION_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Izin Lokasi disetujui!", Toast.LENGTH_SHORT).show();
                checkPermissionsAndStartService();
            } else {
                Toast.makeText(this, "Izin Lokasi wajib disetujui untuk mendeteksi hotspot terdekat.", Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == REQ_CODE_NOTIFICATION_PERMISSION) {
            startHeatmapService();
        }
    }

    private void updateUIState() {
        boolean hasOverlay = true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            hasOverlay = Settings.canDrawOverlays(this);
        }
        boolean hasLocation = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;

        String summary = "Status Otorisasi:\n"
                + "• Izin Overlay Layar: " + (hasOverlay ? "AKTIF (OK)" : "BELUM DIIZINKAN") + "\n"
                + "• Izin GPS Presisi: " + (hasLocation ? "AKTIF (OK)" : "BELUM DIIZINKAN");

        if (tvStatusSummary != null) {
            tvStatusSummary.setText(summary);
        }
    }
}
