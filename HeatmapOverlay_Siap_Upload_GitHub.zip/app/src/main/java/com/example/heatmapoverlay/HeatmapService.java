package com.example.heatmapoverlay;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.os.Build;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class HeatmapService extends Service {

    private static final String TAG = "HeatmapService";
    private static final String CHANNEL_ID = "heatmap_overlay_channel";
    private static final int NOTIFICATION_ID = 1001;
    private static final float RADIUS_THRESHOLD_METERS = 200.0f;

    private WindowManager windowManager;
    private View floatingWidgetView;
    private WindowManager.LayoutParams layoutParams;
    private TextView tvDistanceInfo;
    private ImageView ivStatusIndicator;

    private FusedLocationProviderClient fusedLocationClient;
    private LocationCallback locationCallback;
    private Location currentLocation;

    private FirebaseFirestore firestore;
    private ListenerRegistration firestoreListener;
    private final List<Hotspot> hotspotList = new ArrayList<>();

    @Override
    public void onCreate() {
        super.onCreate();
        startForegroundServiceWithNotification();
        initFloatingWidget();
        initFirestoreHotspots();
        initLocationUpdates();
    }

    private void startForegroundServiceWithNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Heatmap Overlay Monitoring",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Melacak jarak hotspot di latar belakang");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }

        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, notificationIntent,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0
        );

        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Heatmap Overlay Aktif")
                .setContentText("Memantau zona ramai di sekitar Anda...")
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .build();

        startForeground(NOTIFICATION_ID, notification);
    }

    @SuppressLint("InflateParams")
    private void initFloatingWidget() {
        windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        floatingWidgetView = LayoutInflater.from(this).inflate(R.layout.layout_floating_widget, null);
        tvDistanceInfo = floatingWidgetView.findViewById(R.id.tv_distance_info);
        ivStatusIndicator = floatingWidgetView.findViewById(R.id.iv_status_indicator);

        int layoutType;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            layoutType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            layoutType = WindowManager.LayoutParams.TYPE_PHONE;
        }

        layoutParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                layoutType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
        );

        layoutParams.gravity = Gravity.TOP | Gravity.START;
        layoutParams.x = 60;
        layoutParams.y = 180;

        setupDraggableTouchListener();

        if (windowManager != null) {
            windowManager.addView(floatingWidgetView, layoutParams);
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private void setupDraggableTouchListener() {
        floatingWidgetView.setOnTouchListener(new View.OnTouchListener() {
            private int initialX;
            private int initialY;
            private float initialTouchX;
            private float initialTouchY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = layoutParams.x;
                        initialY = layoutParams.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        layoutParams.x = initialX + (int) (event.getRawX() - initialTouchX);
                        layoutParams.y = initialY + (int) (event.getRawY() - initialTouchY);
                        windowManager.updateViewLayout(floatingWidgetView, layoutParams);
                        return true;

                    default:
                        return false;
                }
            }
        });
    }

    private void initFirestoreHotspots() {
        firestore = FirebaseFirestore.getInstance();
        firestoreListener = firestore.collection("hotspots")
                .addSnapshotListener((snapshots, error) -> {
                    if (error != null) {
                        Log.e(TAG, "Gagal memuat Firestore hotspots", error);
                        return;
                    }

                    if (snapshots != null) {
                        hotspotList.clear();
                        for (DocumentSnapshot doc : snapshots.getDocuments()) {
                            Number latNum = doc.get("lat", Number.class);
                            Number lngNum = doc.get("lng", Number.class);
                            String name = doc.getString("name");

                            if (latNum != null && lngNum != null) {
                                hotspotList.add(new Hotspot(
                                        doc.getId(),
                                        latNum.doubleValue(),
                                        lngNum.doubleValue(),
                                        name != null ? name : "Hotspot " + doc.getId().substring(0, 4)
                                ));
                            }
                        }
                        calculateDistanceAndUpdateUI();
                    }
                });
    }

    @SuppressLint("MissingPermission")
    private void initLocationUpdates() {
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        LocationRequest locationRequest;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            locationRequest = new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 10000L)
                    .setMinUpdateIntervalMillis(5000L)
                    .build();
        } else {
            locationRequest = LocationRequest.create();
            locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
            locationRequest.setInterval(10000L);
            locationRequest.setFastestInterval(5000L);
        }

        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult == null) return;
                for (Location location : locationResult.getLocations()) {
                    if (location != null) {
                        currentLocation = location;
                        calculateDistanceAndUpdateUI();
                        break;
                    }
                }
            }
        };

        fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper());
    }

    private void calculateDistanceAndUpdateUI() {
        if (currentLocation == null) {
            tvDistanceInfo.setText("Mencari sinyal GPS...");
            updateWidgetIndicatorColor("#94A3B8");
            return;
        }

        if (hotspotList.isEmpty()) {
            tvDistanceInfo.setText("Tidak ada hotspot aktif");
            updateWidgetIndicatorColor("#94A3B8");
            return;
        }

        float minDistance = Float.MAX_VALUE;
        float[] results = new float[1];

        for (Hotspot spot : hotspotList) {
            Location.distanceBetween(
                    currentLocation.getLatitude(),
                    currentLocation.getLongitude(),
                    spot.getLat(),
                    spot.getLng(),
                    results
            );

            float distanceInMeters = results[0];
            if (distanceInMeters < minDistance) {
                minDistance = distanceInMeters;
            }
        }

        if (minDistance < RADIUS_THRESHOLD_METERS) {
            updateWidgetIndicatorColor("#EF4444");
            tvDistanceInfo.setText("Zona Ramai: Siap Order");
        } else {
            updateWidgetIndicatorColor("#94A3B8");
            if (minDistance >= 1000) {
                float distanceInKm = minDistance / 1000.0f;
                tvDistanceInfo.setText(String.format(Locale.getDefault(), "Jarak ke Hotspot: %.1f km", distanceInKm));
            } else {
                int roundedDistance = Math.round(minDistance);
                tvDistanceInfo.setText(String.format(Locale.getDefault(), "Jarak ke Hotspot: %d meter", roundedDistance));
            }
        }
    }

    private void updateWidgetIndicatorColor(String hexColor) {
        if (ivStatusIndicator != null) {
            GradientDrawable drawable = new GradientDrawable();
            drawable.setShape(GradientDrawable.OVAL);
            drawable.setColor(Color.parseColor(hexColor));
            drawable.setSize(36, 36);
            ivStatusIndicator.setImageDrawable(drawable);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (windowManager != null && floatingWidgetView != null) {
            try {
                windowManager.removeView(floatingWidgetView);
            } catch (Exception ignored) {}
        }
        if (fusedLocationClient != null && locationCallback != null) {
            fusedLocationClient.removeLocationUpdates(locationCallback);
        }
        if (firestoreListener != null) {
            firestoreListener.remove();
        }
    }
}
